// priority: 5

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = true
settings.logErroringRecipes = false

//削除または変更しているレシピはすべてここに記入されているもののみです。
const remove_recipe = {
    "deleting_recipes": [
        "mekanism:basic_control_circuit",
        "mekanism:advanced_control_circuit",
        "mekanism:elite_control_circuit",
        "mekanism:ultimate_control_circuit",
        "mekaevolution:plasma_pickaxe",
        "mekaevolution:plasma_sword",
        "arsomega:alchemical_diamond_block",
        "mekanism:steel_casing",
        "ars_nouveau:source_gem",
        "ars_nouveau:source_gem_block",
        "ars_nouveau:scribes_table",
        "ars_nouveau:arcane_stone",
        "ars_nouveau:imbuement_chamber",
        "ars_nouveau:blaze_fiber",
        "ars_nouveau:end_fiber",
        "ars_nouveau:apprentice_spell_book",
        "ars_nouveau:archmage_spell_book",
        "ars_nouveau:novice_spell_book",
        "powah:dielectric_paste",
        "mekanism:metallurgic_infuser",
        "mekanismgenerators:heat_generator",
        "engineersdecor:metal_bar"
    ]
}
onEvent('recipes', event => {
    event.remove({ output: "#thermal:dynamos" })
    remove_recipe.deleting_recipes.forEach(element => event.remove({ output: element }))
})