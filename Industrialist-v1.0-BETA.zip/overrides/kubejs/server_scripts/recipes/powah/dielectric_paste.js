onEvent('recipes', event =>{
    event.recipes.mekanismMetallurgicInfusing('4x powah:dielectric_paste', '2x minecraft:clay_ball', 'mekanism:carbon', 20)
})