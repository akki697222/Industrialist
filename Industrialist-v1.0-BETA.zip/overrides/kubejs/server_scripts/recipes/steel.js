onEvent('recipes', event => {
    event.recipes.createCompacting('mekanism:ingot_steel', ['#forge:dusts/coal_coke', '#forge:ingots/iron']).heated()
    event.recipes.createCompacting('mekanism:dust_steel', ['#forge:dusts/coal_coke', '#forge:dusts/iron'])
})