onEvent('recipes', event => {
    event.custom({
        type: "powah:energizing",
        ingredients: [
            {item: "immersiveengineering:workbench"},
            {item: "ars_nouveau:source_gem_block"},
            {item: "ars_nouveau:source_berry"},
            {item: "ars_nouveau:archwood_planks"}
        ],
        energy: 5000000,
        result: {
            item: "ars_nouveau:scribes_table"
        },
    })
})