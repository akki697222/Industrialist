onEvent('recipes', event => {
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "minecraft:amethyst_shard" },
            { item: "minecraft:emerald_block" },
            { item: "minecraft:blaze_rod" },
            { item: "minecraft:prismarine_shard" },
            { item: "minecraft:diamond" }
        ],
        energy: 5000000,
        result: {
            item: "arsomega:infused_diamond"
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "minecraft:lapis_block" },
            { item: "minecraft:book" },
            { item: "ars_nouveau:source_gem_block" },
            { item: "ars_nouveau:source_gem_block" },
            { item: "minecraft:gold_block" },
            { item: "arsomega:infused_diamond" }
        ],
        energy: 5000000,
        result: {
            item: "arsomega:enchanted_diamond"
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "minecraft:amethyst_block" },
            { item: "arsomega:arcane_essence" },
            { item: "minecraft:honeycomb" },
            { item: "minecraft:prismarine_crystals" },
            { item: "arsomega:enchanted_diamond" }
        ],
        energy: 5000000,
        result: {
            item: "arsomega:arcane_diamond"
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "minecraft:ghast_tear" },
            { item: "minecraft:netherite_block" },
            { item: "minecraft:netherite_block" },
            { item: "minecraft:netherite_block" },
            { item: "minecraft:netherite_block" }
        ],
        energy: 5000000000,
        result: {
            item: "minecraft:nether_star"
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "minecraft:nether_star" },
            { item: "minecraft:netherite_block" },
            { item: "minecraft:heart_of_the_sea" },
            { item: "ars_nouveau:source_gem" }
        ],
        energy: 5000000,
        result: {
            item: "arsomega:arcane_essence"
        },
    })
})