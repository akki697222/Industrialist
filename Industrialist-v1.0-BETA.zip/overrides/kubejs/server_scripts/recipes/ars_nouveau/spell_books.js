onEvent('recipes', event => {
    event.shapeless('ars_nouveau:novice_spell_book', ['enchanted_book', 'netherite_sword', 'netherite_axe', 'netherite_pickaxe', 'netherite_shovel'])
    event.shapeless('ars_nouveau:apprentice_spell_book', ['ars_nouveau:novice_spell_book', 'crying_obsidian', '3x diamond_block', '2x smooth_quartz', '2x powah:crystal_blazing'])
    event.shapeless('ars_nouveau:archmage_spell_book', ['ars_nouveau:apprentice_spell_book', 'ars_nouveau:wilden_tribute','2x nether_star', 'totem_of_undying','2x netherite_block', 'arsomega:demonic_gem', 'arsomega:infused_diamond'])
})