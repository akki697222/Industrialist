onEvent('recipes', event => {
    event.shaped('ars_nouveau:imbuement_chamber', [
        'ABA',
        'C C',
        'ABA'
    ], {
        A: 'ars_nouveau:archwood_planks',
        B: 'gold_ingot',
        C: 'ars_nouveau:arcane_stone'
    })
})