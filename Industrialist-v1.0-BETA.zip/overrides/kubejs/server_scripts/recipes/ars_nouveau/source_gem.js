onEvent('recipes', event => {
    event.custom({
        type: "powah:energizing",
        ingredients: [{ item: "minecraft:lapis_lazuli" }],
        energy: 1000000,
        result: {
            item: "ars_nouveau:source_gem",
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [{ item: "minecraft:amethyst_shard" }],
        energy: 750000,
        result: {
            item: "ars_nouveau:source_gem",
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [{ item: "minecraft:amethyst_block" }],
        energy: 1500000,
        result: {
            item: "ars_nouveau:source_gem_block",
        },
    })
})