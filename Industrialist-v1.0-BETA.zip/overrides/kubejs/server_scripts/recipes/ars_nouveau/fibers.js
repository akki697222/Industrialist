onEvent('recipes', event => {
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "ars_nouveau:magebloom_fiber" },
            { item: "ars_nouveau:magebloom_fiber" },
            { item: "minecraft:blaze_powder" }
        ],
        energy: 1000000,
        result: {
            item: "ars_nouveau:blaze_fiber",
            count: 2
        },
    })
    event.custom({
        type: "powah:energizing",
        ingredients: [
            { item: "ars_nouveau:blaze_fiber" },
            { item: "ars_nouveau:blaze_fiber" },
            { item: "minecraft:popped_chorus_fruit" }
        ],
        energy: 1000000,
        result: {
            item: "ars_nouveau:end_fiber",
            count: 2
        },
    })
})