onEvent('recipes', event => {
    event.custom({
        type: "powah:energizing",
        ingredients: [
            Ingredient.of('#balm:stones').toJson(),
            Ingredient.of('#balm:stones').toJson(),
            Ingredient.of('#balm:stones').toJson(),
            Ingredient.of('#balm:stones').toJson(),
            {item: "ars_nouveau:source_gem_block"}
        ],
        energy: 500000,
        result: {
            item: "ars_nouveau:arcane_stone",
            count: 4
        },
    })
})