onEvent('recipes', event => {
    event.custom({
        type: "powah:energizing",
        ingredients: [{ item: "minecraft:redstone" }],
        energy: 50000,
        result: {
            item: "fluxnetworks:flux_dust",
        },
    })
})