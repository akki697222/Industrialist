onEvent('recipes', event => {
    event.shaped('draconicevolution:medium_chaos_frag', [
        'AAA',
        'ABA',
        'AAA'
    ], {
        A: 'obsidian',
        B: 'nether_star'
    })
})