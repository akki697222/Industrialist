onEvent('recipes', event => {
    event.recipes.create.mixing(Fluid.of('tconstruct:blazing_blood', 100),['2x blaze_rod']).superheated()
})