onEvent('recipes', event => {
	event.recipes.createSequencedAssembly([
		Item.of('mekanism:steel_casing').withChance(130.0),
		Item.of('immersiveengineering:storage_steel').withChance(7.0),
		Item.of('create:andesite_alloy').withChance(4.0),
		Item.of('create:cogwheel').withChance(5.0),
		Item.of('create:shaft').withChance(2.0),
		Item.of('immersiveengineering:ingot_steel').withChance(8.0)
	],'#forge:storage_blocks/steel',[
		event.recipes.createDeploying('immersiveengineering:storage_steel',['immersiveengineering:storage_steel','create:precision_mechanism']),
		event.recipes.createDeploying('immersiveengineering:storage_steel',['immersiveengineering:storage_steel','mekanism:ingot_osmium']),
		event.recipes.createDeploying('immersiveengineering:storage_steel',['immersiveengineering:storage_steel','thermal:machine_frame']),
        event.recipes.createPressing('immersiveengineering:storage_steel', 'immersiveengineering:storage_steel')
	]).transitionalItem('immersiveengineering:storage_steel').loops(1)
})