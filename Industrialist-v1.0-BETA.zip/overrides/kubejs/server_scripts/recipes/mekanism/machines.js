onEvent('recipes', event => {
    event.shaped('mekanism:metallurgic_infuser', [
        'ABA',
        'CDC',
        'ABA'
    ], {
        A: '#forge:ingots/steel',
        B: 'blast_furnace',
        C: 'immersiveengineering:component_electronic_adv',
        D: 'mekanism:steel_casing'
    })
    event.shaped('mekanismgenerators:heat_generator', [
        'AAA',
        'CDC',
        'BEB'
    ], {
        A: '#forge:sheetmetals/iron',
        B: 'immersiveengineering:coil_lv',
        C: 'immersiveengineering:blastfurnace_preheater',
        D: 'mekanism:steel_casing',
        E: 'furnace'
    })
})