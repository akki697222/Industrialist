onEvent('recipes', event => {
	event.recipes.mekanismMetallurgicInfusing('mekanism:basic_control_circuit', 'immersiveengineering:circuit_board', 'mekanism:redstone', 20)
    event.recipes.mekanismMetallurgicInfusing('mekanism:advanced_control_circuit', 'mekanism:basic_control_circuit', 'mekanism:redstone', 40)
    event.recipes.mekanismMetallurgicInfusing('mekanism:elite_control_circuit', 'mekanism:advanced_control_circuit', 'mekanism:diamond', 40)
    event.recipes.mekanismMetallurgicInfusing('mekanism:ultimate_control_circuit', 'mekanism:elite_control_circuit', 'mekanism:refined_obsidian', 40)
})