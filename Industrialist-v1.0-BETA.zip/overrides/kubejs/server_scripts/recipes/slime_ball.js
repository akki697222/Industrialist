onEvent('recipes', event => {
    event.recipes.mekanismMetallurgicInfusing('minecraft:slime_ball', 'minecraft:clay', 'mekanism:bio', 10)
})