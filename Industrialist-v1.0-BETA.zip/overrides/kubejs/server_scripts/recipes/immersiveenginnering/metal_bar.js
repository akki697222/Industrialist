onEvent('recipes', event => {
    event.shaped('8x engineersdecor:metal_bar', [
        '  A',
        ' A ',
        'A  '
    ], {
        A: '#forge:ingots/steel'
    })
})