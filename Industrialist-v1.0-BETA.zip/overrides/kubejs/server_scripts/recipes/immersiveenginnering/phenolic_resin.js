onEvent('recipes', event => {
    event.recipes.create.mixing(Fluid.of('immersiveengineering:phenolic_resin', 80), [Fluid.of('immersiveengineering:acetaldehyde', 120), Fluid.of('immersiveengineering:creosote', 80)]).superheated()
})