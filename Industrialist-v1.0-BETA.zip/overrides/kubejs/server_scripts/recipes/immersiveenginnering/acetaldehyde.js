onEvent('recipes', event => {
    event.recipes.create.mixing(Fluid.of('immersiveengineering:acetaldehyde', 1000), [Fluid.of('immersiveengineering:ethanol', 1000), '#forge:plates/silver']).heated()
})